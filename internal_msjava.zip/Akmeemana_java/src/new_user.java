import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.Box;
import javax.swing.border.BevelBorder;


public class new_user extends JFrame {

	private JPanel contentPane;
	private JTextField txtusername;

	private JTextField txtusertelephone;
	private JTextField txtaddress;
	private JTextField txtusernic;
	private JPasswordField password;
	private JPasswordField repassword;
	private JTextField txtusertype;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new_user frame = new new_user();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public new_user() {
		setTitle("New User");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 559, 548);
		contentPane = new JPanel();
		contentPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("User Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(70, 74, 93, 25);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("User Type");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(70, 110, 83, 25);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("User Telephone");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(70, 146, 116, 28);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("User Address");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(70, 185, 156, 25);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("User NIC");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(70, 221, 130, 28);
		contentPane.add(lblNewLabel_4);
		
		txtusername = new JTextField();
		txtusername.setBounds(207, 78, 237, 20);
		contentPane.add(txtusername);
		txtusername.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Password");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(70, 260, 144, 25);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Re - Password");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_6.setBounds(70, 296, 130, 27);
		contentPane.add(lblNewLabel_6);
		
		
		
		txtusertelephone = new JTextField();
		txtusertelephone.setBounds(207, 152, 237, 20);
		contentPane.add(txtusertelephone);
		txtusertelephone.setColumns(10);
		
		txtaddress = new JTextField();
		txtaddress.setBounds(207, 189, 237, 20);
		contentPane.add(txtaddress);
		txtaddress.setColumns(10);
		
		txtusernic = new JTextField();
		txtusernic.setBounds(207, 227, 237, 20);
		contentPane.add(txtusernic);
		txtusernic.setColumns(10);
		
		password = new JPasswordField();
		password.setBounds(207, 264, 237, 20);
		contentPane.add(password);
		
		repassword = new JPasswordField();
		repassword.setBounds(207, 301, 237, 20);
		contentPane.add(repassword);
		
		JButton btnsubmit = new JButton("Submit");
		btnsubmit.setFont(new Font("Tahoma", Font.BOLD, 19));
		btnsubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try
		        {
		            
		            boolean check = true;		            
		            
		                String username = txtusername.getText().trim();
		                String usertype = txtusertype.getText().trim();
		                String usertelephone = txtusertelephone.getText();
		                String useraddress = txtaddress.getText();
		                String usernic = txtusernic.getText();
		                String userpassword = password.getText();
		                String userrepassword = repassword.getText();
		                
		                String message ="";
		                
		                if(username.isEmpty())
		                {
		                    check = false;
		                    message = "User name is Empty";
		                }
		                if(usertelephone.isEmpty())
		                {
		                    check = false;
		                    message = "User Telephone is Empty";
		                }
		                if(useraddress.isEmpty())
		                {
		                    check = false;
		                    message = "user address is Empty";
		                }
		                if(usernic.isEmpty())
		                {
		                    check = false;
		                    message = "user NIC is Empty";
		                }
		                if(userpassword.isEmpty())
		                {
		                    check = false;
		                    message = "Please use password";
		                }
		                if(!userrepassword.equals(userpassword))
		                {
		                    check = false;
		                    message = "Passwords do not match";
		                    
		                }

		                if(check)
		                {
		                    String Pass = userpassword = userrepassword;
		                   
		                    DB db = new DB();
		                    String query = "INSERT INTO user (user_name,user_type,user_telephone,user_address,user_nic,password) VALUES ('"+username+"','"+usertype+"','"+usertelephone+"','"+useraddress+"','"+usernic+"','"+userrepassword+"')";

		                    int rows = db.Save_Del_Update(query);

		                    if (rows>0)
		                    {
		                        //output_lbl.setText("Data Inserted Successfully. "+rows+" Rows inserted");
		                    	//JOptionPane.showMessageDialog(null, "Please fill all fields","Login Error",JOptionPane.ERROR_MESSAGE);
		                    	//JOptionPane.showMessageDialog(null, "Data inserted sucessfully ","Insert Error",JOptionPane.ERROR_MESSAGE);
		                    	JOptionPane.showMessageDialog( null, "Data Insertion Sucessful !" );
		                    	//clear
		                    	txtusername.setText("");
		        				//comboBox.setToolTipText("");
		        				txtusertelephone.setText("");
		        				txtaddress.setText("");
		        				txtusernic.setText("");
		        				password.setText("");
		        				repassword.setText("");
		        				
		                        
		                    }
		                    else
		                    {
		                      // output_lbl.setText("Data insertion failed. "+rows+" Rows inserted");
		                        JOptionPane.showMessageDialog(null, "Data insertion failed ","Insert Error",JOptionPane.ERROR_MESSAGE);

		                    }
		                }
		                else
		                {
		           //         output_lbl.setText(message);
		                    javax.swing.JOptionPane.showMessageDialog(null, 
		                              message, 
		                              "Error", 
		                             javax.swing.JOptionPane.WARNING_MESSAGE);
		                           //  */
		                //	 JOptionPane.showMessageDialog(null, "Data insertion failed XX","Insert Error",JOptionPane.ERROR_MESSAGE);
		
		                }
		        }
		        catch(SQLException ex)
		        {
		                javax.swing.JOptionPane.showMessageDialog(null,
		                    ex.getMessage(),
		                    "SQL Exception",
		                    javax.swing.JOptionPane.WARNING_MESSAGE);
		        }
				
				
				
				
			}
		});
		btnsubmit.setBounds(186, 410, 168, 62);
		contentPane.add(btnsubmit);
		
		JButton btnclear = new JButton("Clear");
		btnclear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//clear
            	txtusername.setText("");
				txtusertelephone.setText("");
				txtaddress.setText("");
				txtusernic.setText("");
				password.setText("");
				repassword.setText("");
			}
		});
		btnclear.setBounds(355, 332, 89, 23);
		contentPane.add(btnclear);
		
		txtusertype = new JTextField();
		txtusertype.setEditable(false);
		txtusertype.setText("User");
		txtusertype.setBounds(207, 114, 237, 20);
		contentPane.add(txtusertype);
		txtusertype.setColumns(10);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox.setBounds(41, 57, 440, 332);
		contentPane.add(horizontalBox);
	}
}
