import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.Box;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.border.BevelBorder;
import java.awt.Color;

public class delete_customer extends JFrame {

	private JPanel contentPane;
	private JTextField txtcustomerid;
	private JTextField txtcustomername;
	
	private JComboBox comtelephone;
	private String cId;
	private String cName;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					delete_customer frame = new delete_customer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public delete_customer() {
		setTitle("Delete Customer");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 507, 427);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		comtelephone = new JComboBox();
		comtelephone.setBounds(272, 72, 195, 22);
		contentPane.add(comtelephone);
		
		JLabel lblNewLabel = new JLabel("Select Customer Telephone Number");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(23, 74, 283, 14);
		contentPane.add(lblNewLabel);
		
		txtcustomerid = new JTextField();
		txtcustomerid.setEditable(false);
		txtcustomerid.setBounds(217, 176, 158, 20);
		contentPane.add(txtcustomerid);
		txtcustomerid.setColumns(10);
		
		txtcustomername = new JTextField();
		txtcustomername.setEditable(false);
		txtcustomername.setBounds(217, 211, 158, 20);
		contentPane.add(txtcustomername);
		txtcustomername.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Customer Name");
		lblNewLabel_1.setBounds(102, 214, 86, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Customer ID");
		lblNewLabel_2.setBounds(102, 179, 105, 14);
		contentPane.add(lblNewLabel_2);
		
		JButton btndelete = new JButton("Delete");
		btndelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//delete customer
				try {
					cId=txtcustomerid.getText();
					
					if (cId.isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Error occured","Try again",JOptionPane.ERROR_MESSAGE);   
					}
					else
					{
						  DB db = new DB();
		                  String query = "DELETE FROM `customer` WHERE cus_id='"+cId+"'";
		                     
		                 
		                    	
		                    		 int rows = db.Save_Del_Update(query);
		                    		 if (rows>0) {
		                    			 JOptionPane.showMessageDialog( null, "Data Deletion Sucessful !" );
		                    			//clear
		                 				txtcustomerid.setText("");
		                 				txtcustomername.setText("");
		                 				
		     	                         
		                    		 }  
		                        
		                    
					}
					}catch(Exception e1) {
			             
			             javax.swing.JOptionPane.showMessageDialog(null, 
			                     e1.getMessage(), 
			                     " Exception", 
			                     javax.swing.JOptionPane.WARNING_MESSAGE);	}
				
			}
		});
		btndelete.setFont(new Font("Tahoma", Font.BOLD, 17));
		btndelete.setBounds(162, 308, 145, 57);
		contentPane.add(btndelete);
		
		JButton btnclear = new JButton("Clear");
		btnclear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//clear
				txtcustomerid.setText("");
				txtcustomername.setText("");
				
			}
		});
		btnclear.setBounds(303, 242, 70, 23);
		contentPane.add(btnclear);
		
		Box horizontalBox_1 = Box.createHorizontalBox();
		horizontalBox_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_1.setBounds(76, 155, 325, 132);
		contentPane.add(horizontalBox_1);
		
		JButton btnsearch = new JButton("Search");
		btnsearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
//search btn
				
				try {
					
					String mobilenumber = comtelephone.getSelectedItem().toString();
					// String  = txtsearch.getText();
				
					if (mobilenumber.trim().isEmpty() )
		            {
		            
						JOptionPane.showMessageDialog(null, "Please fill all fields","Login Error",JOptionPane.ERROR_MESSAGE);
		                
		            }
		            else
		            {
		                
		                
		                DB db = new DB();
		                String query = "SELECT * FROM customer WHERE cus_telephone='"+mobilenumber+"'";
		                ResultSet rs = db.GetData(query);
		                
		                
		                rs.next();
		                int rows = rs.getRow();
		                
		                
		                if (rows>0)
		                {
		                	cId = rs.getString("cus_id");
		                	cName = rs.getString("cus_name");
		                	
		                	
		                	
		                	txtcustomerid.setText(cId);
		                	txtcustomername.setText(cName);
		                	
		                
		                
							
		                    
		                  //  db.closeCon();
		                    
		                }
		                else
		                {
		        
		                	JOptionPane.showMessageDialog(null, "Invalid customer mobile number","Try again",JOptionPane.ERROR_MESSAGE);
			                
		                }	
		            }}
				
				catch(SQLException e1)
		        {
		            javax.swing.JOptionPane.showMessageDialog(null, 
		                              e1.getMessage(), 
		                              "SQL Exception", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);	}
				
				
			}
		});
		btnsearch.setBounds(272, 105, 89, 23);
		contentPane.add(btnsearch);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox.setBounds(10, 54, 471, 87);
		contentPane.add(horizontalBox);
		
		JLabel lblNewLabel_3 = new JLabel("WARNING! When you delete the details it shoud be erase all of data records.");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_3.setBounds(23, 11, 444, 22);
		contentPane.add(lblNewLabel_3);
		CustomeraAddCombo();
	}
	
	
	//comvbo bvox load 
	private void CustomeraAddCombo()
    {
	try {
	 DB db = new DB();
	 String query = "SELECT cus_telephone FROM customer";
	 ResultSet rs = db.GetData(query);
  
  
	 while(rs.next())
	 {
  
		 comtelephone.addItem(rs.getString(1));
	 }

	}catch(Exception e1) {
  
	javax.swing.JOptionPane.showMessageDialog(null, 
          e1.getMessage(), 
          " Exception", 
          javax.swing.JOptionPane.WARNING_MESSAGE);	}


    }
}
