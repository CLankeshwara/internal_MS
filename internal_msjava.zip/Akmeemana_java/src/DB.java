
import java.sql.*;
public class DB {

	String path = "jdbc:mysql://localhost:3306/akmeemana";
	Connection con;
	Statement st;

	public void setPath(String p)
	{
		path = p;
	}
	

	public void closeCon() throws SQLException
	{
		con.close();
	}
	
	public int Save_Del_Update(String query) throws SQLException
	{
		con = DriverManager.getConnection(path,"root","");
		st = con.createStatement();

		int rows = st.executeUpdate(query);
		closeCon();
		return rows;
	}
	
	public ResultSet GetData(String query) throws SQLException
	{
		con = DriverManager.getConnection(path,"root","");
		st = con.createStatement();

		ResultSet rs = st.executeQuery(query);
		return rs;
	}
	
}
