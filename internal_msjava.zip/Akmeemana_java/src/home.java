import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Box;
import javax.swing.border.BevelBorder;
import java.awt.Color;
import java.awt.SystemColor;

public class home extends JFrame {

	private JPanel home;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					home frame = new home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public home() {
		setTitle("Main Menu - Admin");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 580, 480);
		home = new JPanel();
		home.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(home);
		home.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("HOME");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel.setBounds(226, 21, 89, 36);
		home.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Create Order");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame crateorder = new neworder();
				crateorder.setVisible(true);
				home.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnNewButton.setBounds(23, 89, 228, 52);
		home.add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Delete Order");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame delete = new delete_order();
				delete.setVisible(true);
				home.setVisible(true);
			
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnNewButton_2.setBounds(295, 89, 209, 52);
		home.add(btnNewButton_2);
		
		JButton btncustomercontrol = new JButton("Customer Control");
		btncustomercontrol.setFont(new Font("Tahoma", Font.BOLD, 15));
		btncustomercontrol.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				JFrame customer_control = new customer_control();
				customer_control.setVisible(true);
				home.setVisible(true);
			
				
				
			}
		});
		btncustomercontrol.setBounds(23, 174, 228, 146);
		home.add(btncustomercontrol);
		
		JButton btnNewButton_4 = new JButton("Add User");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame adduser = new new_user();
				adduser.setVisible(true);
				home.setVisible(true);
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_4.setBounds(295, 182, 184, 36);
		home.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Reports");
		btnNewButton_5.setForeground(Color.WHITE);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame output = new report_menu();
				output.setVisible(true);
				home.setVisible(true);
				
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_5.setBackground(Color.BLACK);
		btnNewButton_5.setBounds(55, 331, 421, 67);
		home.add(btnNewButton_5);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.GREEN, null, null, null));
		horizontalBox.setBounds(10, 79, 521, 78);
		home.add(horizontalBox);
		
		JButton btnNewButton_3 = new JButton("Change Password");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame change = new update_user();
				change.setVisible(true);
				home.setVisible(true);
				
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_3.setBounds(295, 229, 184, 36);
		home.add(btnNewButton_3);
		
		JButton btndeleteuser = new JButton("Delete User");
		btndeleteuser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame delete = new delete_user();
				delete.setVisible(true);
				home.setVisible(true);
			}
		});
		btndeleteuser.setFont(new Font("Tahoma", Font.BOLD, 15));
		btndeleteuser.setBounds(295, 276, 184, 36);
		home.add(btndeleteuser);
		
		Box horizontalBox_1 = Box.createHorizontalBox();
		horizontalBox_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_1.setBounds(283, 174, 208, 146);
		home.add(horizontalBox_1);
		
		JButton btnNewButton_1 = new JButton("Sign Out");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(Color.RED);
		btnNewButton_1.setBounds(442, 21, 89, 23);
		home.add(btnNewButton_1);
	}
}
