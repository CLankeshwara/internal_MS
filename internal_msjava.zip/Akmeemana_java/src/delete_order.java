import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Box;
import javax.swing.border.BevelBorder;
import java.awt.Color;

public class delete_order extends JFrame {

	private JPanel contentPane;
	private JTextField txtorderid;
	private JTextField txtcustomername;
	
	private JComboBox comorderid;
	private String oId;
	private String cName;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					delete_order frame = new delete_order();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public delete_order() {
		setTitle("Delete Order");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 516, 432);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Select Order ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(86, 90, 136, 14);
		contentPane.add(lblNewLabel);
		
		comorderid = new JComboBox();
		comorderid.setBounds(232, 88, 197, 22);
		contentPane.add(comorderid);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					String order = comorderid.getSelectedItem().toString();
				   // String  = txtsearch.getText();
				
					if (order.trim().isEmpty() )
		            {
		            
						JOptionPane.showMessageDialog(null, "Please fill all fields","Login Error",JOptionPane.ERROR_MESSAGE);
		                
		            }
		            else
		            {
		                
		                
		                DB db = new DB();
		                String query = "SELECT * FROM neworder WHERE order_id='"+order+"'";
		                ResultSet rs = db.GetData(query);
		                
		                
		                rs.next();
		                int rows = rs.getRow();
		                
		                
		                if (rows>0)
		                {
		                	 oId = rs.getString("order_id");
		                	 cName = rs.getString("cus_name");
		                	
		                	
		                
		                	
		                	txtorderid.setText(oId);
		                	txtcustomername.setText(cName);
		                	
		                	
		                	
		                
		                    
		                }
		                else
		                {
		        
		                	JOptionPane.showMessageDialog(null, "Invalid order ID","Try again",JOptionPane.ERROR_MESSAGE);
			                
		                }	
		            }}
				
				catch(SQLException e1)
		        {
		            javax.swing.JOptionPane.showMessageDialog(null, 
		                              e1.getMessage(), 
		                              "SQL Exception", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);	}
				
				
				
			}
		});
		btnNewButton.setBounds(231, 121, 80, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Order ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(83, 202, 80, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Customer Name");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(83, 232, 107, 14);
		contentPane.add(lblNewLabel_2);
		
		txtorderid = new JTextField();
		txtorderid.setBounds(229, 201, 197, 20);
		contentPane.add(txtorderid);
		txtorderid.setColumns(10);
		
		txtcustomername = new JTextField();
		txtcustomername.setBounds(229, 231, 197, 20);
		contentPane.add(txtcustomername);
		txtcustomername.setColumns(10);
		
		JButton btndelete = new JButton("Delete");
		btndelete.setFont(new Font("Tahoma", Font.BOLD, 15));
		btndelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					oId=txtorderid.getText();
					
					if (oId.isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Error occured","Try again",JOptionPane.ERROR_MESSAGE);   
					}
					else
					{
						  DB db = new DB();
		                  String query = "DELETE FROM `neworder` WHERE order_id='"+oId+"'";
		                     
		                 
		                    	
		                    		 int rows = db.Save_Del_Update(query);
		                    		 if (rows>0) {
		                    			 JOptionPane.showMessageDialog( null, "Data Deletion Sucessful !" );
		                    			//clear
		                 				txtorderid.setText("");
		                 				txtcustomername.setText("");
		                 				
		     	                         
		                    		 }  
		                        
		                    
					}
					}catch(Exception e1) {
			             
			             javax.swing.JOptionPane.showMessageDialog(null, 
			                     e1.getMessage(), 
			                     " Exception", 
			                     javax.swing.JOptionPane.WARNING_MESSAGE);	}
				
				
			}
		});
		btndelete.setBounds(186, 291, 122, 47);
		contentPane.add(btndelete);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox.setBounds(22, 69, 449, 85);
		contentPane.add(horizontalBox);
		
		Box horizontalBox_1 = Box.createHorizontalBox();
		horizontalBox_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_1.setBounds(65, 184, 383, 96);
		contentPane.add(horizontalBox_1);
		
		JLabel lblNewLabel_3 = new JLabel("WARNING! When you delete the details it shoud be erase all of data records.");
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_3.setBounds(34, 25, 444, 22);
		contentPane.add(lblNewLabel_3);
		orderidadd();
	}
	private void orderidadd()
    {
	try {
	 DB db = new DB();
	 String query = "SELECT order_id FROM neworder";
	 ResultSet rs = db.GetData(query);
  
  
	 while(rs.next())
	 {
  
		 comorderid.addItem(rs.getString(1));
	 }

	}catch(Exception e1) {
  
	javax.swing.JOptionPane.showMessageDialog(null, 
          e1.getMessage(), 
          " Exception", 
          javax.swing.JOptionPane.WARNING_MESSAGE);	}


    }
}
