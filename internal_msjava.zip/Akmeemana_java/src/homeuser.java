import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class homeuser extends JFrame {

	private JPanel homeuser;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					homeuser frame = new homeuser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public homeuser() {
		setTitle("Main Menu  - User");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 535, 415);
		homeuser = new JPanel();
		homeuser.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(homeuser);
		homeuser.setLayout(null);
		
		JButton btnsignout = new JButton("Sign Out");
		btnsignout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnsignout.setForeground(Color.WHITE);
		btnsignout.setBackground(Color.RED);
		btnsignout.setBounds(420, 11, 89, 23);
		homeuser.add(btnsignout);
		
		JButton btnNewButton = new JButton("Create Order");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame ordernew = new neworder();
				ordernew.setVisible(true);
				homeuser.setVisible(true);
			
			}
		});
		btnNewButton.setBackground(Color.YELLOW);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(43, 45, 428, 55);
		homeuser.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New Customer");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame newcus = new new_customer();
				newcus.setVisible(true);
				homeuser.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(43, 145, 175, 55);
		homeuser.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update Customer");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame editcus = new edit_customer();
				editcus.setVisible(true);
				homeuser.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(43, 218, 175, 55);
		homeuser.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Add User");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame adduse = new new_user();
				adduse.setVisible(true);
				homeuser.setVisible(true);
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_3.setBounds(296, 147, 175, 55);
		homeuser.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Password Change");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame forget = new update_user();
				forget.setVisible(true);
				homeuser.setVisible(true);
				
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_4.setBounds(296, 220, 175, 55);
		homeuser.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Reports");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame rep = new report_menu();
				rep.setVisible(true);
				homeuser.setVisible(true);
				
				
			}
		});
		btnNewButton_5.setForeground(Color.WHITE);
		btnNewButton_5.setBackground(Color.BLACK);
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_5.setBounds(43, 307, 428, 58);
		homeuser.add(btnNewButton_5);
	}
}
