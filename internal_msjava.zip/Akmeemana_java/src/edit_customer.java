import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.Box;
import java.awt.Font;
import javax.swing.border.BevelBorder;

public class edit_customer extends JFrame {

	private JPanel contentPane;
	private JTextField txtcustomerid;
	private JTextField txtcustomername;
	private JTextField txtcustomertepehone;
	private JTextField txtcustomeraddress;
	private JTextField txtcustomernic;
	private JTable table;
	private JComboBox cmbCusNo;
	private Boolean notEmpty;
	
	DefaultTableModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					edit_customer frame = new edit_customer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public edit_customer() {
		setTitle("Edit Customer");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 462, 411);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Customer ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(48, 132, 128, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Customer Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(48, 157, 128, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Customer Telepehone");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(48, 182, 168, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Customer Address");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(48, 207, 168, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Customer NIC");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(48, 232, 140, 14);
		contentPane.add(lblNewLabel_4);
		
		txtcustomerid = new JTextField();
		txtcustomerid.setEditable(false);
		txtcustomerid.setBounds(216, 131, 158, 20);
		contentPane.add(txtcustomerid);
		txtcustomerid.setColumns(10);
		
		txtcustomername = new JTextField();
		txtcustomername.setBounds(216, 156, 158, 20);
		contentPane.add(txtcustomername);
		txtcustomername.setColumns(10);
		
		txtcustomertepehone = new JTextField();
		txtcustomertepehone.setBounds(216, 181, 158, 20);
		contentPane.add(txtcustomertepehone);
		txtcustomertepehone.setColumns(10);
		
		txtcustomeraddress = new JTextField();
		txtcustomeraddress.setBounds(216, 206, 158, 20);
		contentPane.add(txtcustomeraddress);
		txtcustomeraddress.setColumns(10);
		
		txtcustomernic = new JTextField();
		txtcustomernic.setBounds(216, 231, 158, 20);
		contentPane.add(txtcustomernic);
		txtcustomernic.setColumns(10);
		
		//
		
		
		
		
		
		
		///scrollPane = new JScrollPane();
		///scrollPane.setBounds(312, 38, 266, 236);
		
		
		///contentPane.add(scrollPane);
		
		///table = new JTable();
		///scrollPane.setViewportView(table);
		
		JButton btnupdate = new JButton("Update");
		btnupdate.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnupdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			//update details
		            try
		            {
		            	
		            	notEmpty = true;
		    	        String message = "";
		    	        
		    	        TextValidations();
		    	        if(txtcustomerid.getText().trim().isEmpty())
		    	        {
		    	            notEmpty = false;
		    	            message = "Customer ID is empty";
		    	        }
		    	        if(txtcustomername.getText().trim().isEmpty())
		    	        {
		    	            notEmpty = false;
		    	            message = "Customer customer Name is empty";
		    	        }
		    	        if(txtcustomertepehone.getText().trim().isEmpty())
		    	        {
		    	            notEmpty = false;
		    	            message = "Customer Telephone number is empty";
		    	        }
		    	        if(txtcustomeraddress.getText().trim().isEmpty())
		    	        {
		    	            notEmpty = false;
		    	            message = "Customer address is empty";
		    	        }
		    	        if(txtcustomernic.getText().trim().isEmpty())
		    	        {
		    	            notEmpty = false;
		    	            message = "Customer NIC number is empty";
		    	        }
		    	        
		    	        
		    	        
		    	        if(!notEmpty)
		    	        {
		    	            javax.swing.JOptionPane.showMessageDialog(null, 
		    	                              message, 
		    	                              "Empty", 
		    	                              javax.swing.JOptionPane.WARNING_MESSAGE);
		    	        }
		    	        
		    	      
		            	
		            	
		            	
		            	
		            	
		            	String cId = txtcustomerid.getText();
		                String cName = txtcustomername.getText().trim();
	                	String ctele = txtcustomertepehone.getText().trim();
	                	String cAddress = txtcustomeraddress.getText().trim();
	                	String cNic = txtcustomernic.getText().trim();
	                	            
		                
		                DB db = new DB();
		                String query = "UPDATE customer SET cus_name = '"+cName+"' , cus_telephone = '"+ctele+"' , cus_nic = '"+cNic+"' , cus_address = '"+cAddress+"' ";
		                int rows = db.Save_Del_Update(query);
		                
		                if (rows>0)
		                {

		            		
		                    
		                    javax.swing.JOptionPane.showMessageDialog(null, 
		                              "Data Updated Successfully. "+rows+" Rows updated", 
		                              "Message", 
		                              javax.swing.JOptionPane.INFORMATION_MESSAGE);
		                    
		                   
		                    txtcustomerid.setText("");
		    		        txtcustomername.setText("");
		    		        txtcustomertepehone.setText("");
		    		        txtcustomeraddress.setText("");
		    		        txtcustomernic.setText("");
		                }
		                else
		                {
		                    
		                    javax.swing.JOptionPane.showMessageDialog(null, 
		                              "Data Update failed. "+rows+" Rows updated", 
		                              "Error", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);
		                }
		            }
		            catch(java.sql.SQLException e1)
		            {
		                javax.swing.JOptionPane.showMessageDialog(null, 
		                              e1.getMessage(), 
		                              "SQL Exception", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);
		            }
		            
		            
		        
				
				
				
				
				
			}
		});
		btnupdate.setBounds(135, 295, 134, 50);
		contentPane.add(btnupdate);
		
		cmbCusNo = new JComboBox();
		cmbCusNo.setBounds(216, 48, 158, 22);
		contentPane.add(cmbCusNo);
		
		JButton btnclear = new JButton("Clear");
		btnclear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//clear
				txtcustomerid.setText("");
		        txtcustomername.setText("");
		        txtcustomertepehone.setText("");
		        txtcustomeraddress.setText("");
		        txtcustomernic.setText("");
				
				
				
			}
		});
		btnclear.setBounds(306, 253, 68, 23);
		contentPane.add(btnclear);
		
		
		JButton btnsearch = new JButton("Search");
		btnsearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//search btn
				
				try {
					
					String mobilenumber = cmbCusNo.getSelectedItem().toString();
					// String  = txtsearch.getText();
				
					if (mobilenumber.trim().isEmpty() )
		            {
		            
						JOptionPane.showMessageDialog(null, "Please fill all fields","Login Error",JOptionPane.ERROR_MESSAGE);
		                
		            }
		            else
		            {
		                
		                
		                DB db = new DB();
		                String query = "SELECT * FROM customer WHERE cus_telephone='"+mobilenumber+"'";
		                ResultSet rs = db.GetData(query);
		                
		                
		                rs.next();
		                int rows = rs.getRow();
		                
		                
		                if (rows>0)
		                {
		                	String cId = rs.getString("cus_id");
		                	String cName = rs.getString("cus_name");
		                	String ctele = rs.getString("cus_telephone");
		                	String cadd = rs.getString("cus_address");
		                	String cnic = rs.getString("cus_nic");
		                	
		                	
		                	txtcustomerid.setText(cId);
		                	txtcustomername.setText(cName);
		                	txtcustomertepehone.setText(ctele);
		                	txtcustomeraddress.setText(cadd);
		                	txtcustomernic.setText(cnic);
		                
		                
							
		                    
		                  //  db.closeCon();
		                    
		                }
		                else
		                {
		        
		                	JOptionPane.showMessageDialog(null, "Invalid customer mobile number","Try again",JOptionPane.ERROR_MESSAGE);
			                
		                }	
		            }}
				
				catch(SQLException e1)
		        {
		            javax.swing.JOptionPane.showMessageDialog(null, 
		                              e1.getMessage(), 
		                              "SQL Exception", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);	}
				
				
				
				
				
				
			}
		});
		btnsearch.setBounds(216, 81, 80, 23);
		contentPane.add(btnsearch);
		
		JLabel lblNewLabel_5 = new JLabel("Customer Telephone Number");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(26, 52, 180, 14);
		contentPane.add(lblNewLabel_5);
		
		Box horizontalBox_1 = Box.createHorizontalBox();
		horizontalBox_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_1.setBounds(10, 32, 412, 78);
		contentPane.add(horizontalBox_1);
		CustomeraAddCombo();
	}
	
	
	

	
	//search
	private void CustomeraAddCombo()
    {
	try {
	 DB db = new DB();
	 String query = "SELECT cus_telephone FROM customer";
	 ResultSet rs = db.GetData(query);
  
  
	 while(rs.next())
	 {
  
		 cmbCusNo.addItem(rs.getString(1));
	 }

	}catch(Exception e1) {
  
	javax.swing.JOptionPane.showMessageDialog(null, 
          e1.getMessage(), 
          " Exception", 
          javax.swing.JOptionPane.WARNING_MESSAGE);	}


    }
	
	
	//validations
	private void TextValidations()
    {	
		// contact one text length check
		String txtcon1ST=txtcustomertepehone.getText();
		ContactLengthTest(txtcon1ST,"Contact Mobile length is not valid");
		
		// contact one character check
		CharachterTest(txtcon1ST,"Contact Mobile can only contain numbers");
	
		// nic number text length check 
		String txtnicST;
		txtnicST=txtcustomernic.getText();
		if (txtnicST.length()==10 || txtnicST.length()==12) {
			
		}
		else {
			notEmpty = false;
			JOptionPane.showMessageDialog(null, "NIC number is not valid:", "Validation Error",JOptionPane.WARNING_MESSAGE);
		}
		
    }
	
	private void ContactLengthTest(String ContactLengthTestInput, String MessageZ)
    {

	if (ContactLengthTestInput.length()!=10) {
		notEmpty = false;
		JOptionPane.showMessageDialog(null, MessageZ , "Validation Error",JOptionPane.WARNING_MESSAGE);
	} 
    }
	
	
	
	
	
private void CharachterTest(String CharTestInput,String MessageX) {
		
		char[] txtConArrX = CharTestInput.toCharArray();
		char[] numX = {'0','1','2','3','4','5','6','7','8','9'};
		int j;

		
		for (int i = 0; i < txtConArrX.length; i++) {
		
			  for( j = 0; j < numX.length; j++) {
				  System.out.println("txtConArrX[i]: "+String.valueOf(txtConArrX[i]));
				  System.out.println("numX[j]: "+String.valueOf(numX[j]));
			    if (txtConArrX[i]==numX[j]) {
			
			    	break;
			    }
			    
			  }
			  if ((numX.length)==j) {
				 // System.out.println(numX[i]);
				  JOptionPane.showMessageDialog(null, MessageX, "Validation Error",JOptionPane.WARNING_MESSAGE);
				  notEmpty = false;
				  break;
			  }
			  
			 
			}		

	}
	
	
}
