import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;

import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.border.BevelBorder;
import java.awt.Color;

public class neworder extends JFrame {

	private JPanel contentPane;
	private JTextField txtcusid;
	private JTextField txtcusname;
	private JTextField txtcusnic;
	private JTextField txtorderid;
	private JTextField txtdiscription;
	private JTextField txtquantity;
	private JTextField txtprice;
	private JTextField txtdiscount;
	private JTextField txttotal;
	private String orderprice;
	private String orderdiscount;
	private String ordertotal;
	private String orderid;
	private String cusid;
	private String cusname;
	private String cusnic;
	private String discription;
	private String quantity;
	private String jtype;
	private String todaydate;
	private String orderequall;
	
	private JComboBox comtelephone;
	
	
	private JDateChooser currentdate;
	
	private Date xdate = new Date();
	private JTextField textField;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					neworder frame = new neworder();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public neworder() {
		setTitle("Order");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 753, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		currentdate = new JDateChooser();
		currentdate.setBounds(139, 34, 179, 20);
		contentPane.add(currentdate);
		currentdate.setDateFormatString("yyyy/MM/dd");
		currentdate.setDate(xdate);
		
		
		JLabel lblNewLabel = new JLabel("Customer Telephone");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(373, 40, 148, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Customer ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(373, 108, 148, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Customer NIC");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(373, 159, 148, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Customer Name");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(373, 134, 148, 14);
		contentPane.add(lblNewLabel_3);
		
		txtcusid = new JTextField();
		txtcusid.setEditable(false);
		txtcusid.setBounds(524, 105, 191, 20);
		contentPane.add(txtcusid);
		txtcusid.setColumns(10);
		
		txtcusname = new JTextField();
		txtcusname.setEditable(false);
		txtcusname.setBounds(524, 131, 191, 20);
		contentPane.add(txtcusname);
		txtcusname.setColumns(10);
		
		txtcusnic = new JTextField();
		txtcusnic.setEditable(false);
		txtcusnic.setBounds(524, 156, 191, 20);
		contentPane.add(txtcusnic);
		txtcusnic.setColumns(10);
		
		comtelephone = new JComboBox();
		comtelephone.setEditable(true);
		comtelephone.setBounds(526, 34, 189, 22);
		contentPane.add(comtelephone);
		
		JLabel lblNewLabel_4 = new JLabel("Date");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_4.setBounds(24, 40, 78, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Order ID");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(24, 71, 78, 14);
		contentPane.add(lblNewLabel_5);
		
		txtorderid = new JTextField();
		txtorderid.setEditable(false);
		txtorderid.setBounds(139, 68, 160, 20);
		contentPane.add(txtorderid);
		txtorderid.setColumns(10);
		generate_orderid();
		
		JButton btncussearch = new JButton("Search");
		btncussearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//search btn
				
				try {
					
					String mobilenumber = comtelephone.getSelectedItem().toString();
					// String  = txtsearch.getText();
				
					if (mobilenumber.trim().isEmpty() )
		            {
		            
						JOptionPane.showMessageDialog(null, "Please fill all fields","Login Error",JOptionPane.ERROR_MESSAGE);
		                
		            }
		            else
		            {
		                
		                
		                DB db = new DB();
		                String query = "SELECT * FROM customer WHERE cus_telephone='"+mobilenumber+"'";
		                ResultSet rs = db.GetData(query);
		                
		                
		                rs.next();
		                int rows = rs.getRow();
		                
		                
		                if (rows>0)
		                {
		                	String cId = rs.getString("cus_id");
		                	String cName = rs.getString("cus_name");
		                	String ctele = rs.getString("cus_telephone");
		                	//String cadd = rs.getString("cus_address");
		                	String cnic = rs.getString("cus_nic");
		                	
		                	
		                	txtcusid.setText(cId);
		                	txtcusname.setText(cName);
		                	//txtcustomeraddress.setText(cadd);
		                	txtcusnic.setText(cnic);
		                
		                
							
		                    
		                  //  db.closeCon();
		                    
		                }
		                else
		                {
		        
		                	JOptionPane.showMessageDialog(null, "Invalid customer mobile number","Try again",JOptionPane.ERROR_MESSAGE);
			                
		                }	
		            }}
				
				catch(SQLException e1)
		        {
		            javax.swing.JOptionPane.showMessageDialog(null, 
		                              e1.getMessage(), 
		                              "SQL Exception", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);	}
				
			}
		});
		btncussearch.setBounds(524, 67, 93, 23);
		contentPane.add(btncussearch);
		
		JButton btnNewButton_1 = new JButton("New");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFrame new_customer = new new_customer();
				new_customer.setVisible(true);
				//.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(622, 67, 93, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_6 = new JLabel("Order Type");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_6.setBounds(24, 183, 114, 14);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Order Discription");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_7.setBounds(24, 215, 114, 14);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Order Quantity");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_8.setBounds(24, 302, 114, 14);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Order Price");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_9.setBounds(24, 330, 114, 14);
		contentPane.add(lblNewLabel_9);
		
		JComboBox comordertype = new JComboBox();
		comordertype.setModel(new DefaultComboBoxModel(new String[] {"Ring", "Chane", "Baselat"}));
		comordertype.setBounds(144, 181, 130, 22);
		contentPane.add(comordertype);
		
		txtdiscription = new JTextField();
		txtdiscription.setBounds(139, 215, 165, 81);
		contentPane.add(txtdiscription);
		txtdiscription.setColumns(10);
		
		txtquantity = new JTextField();
		txtquantity.setBounds(139, 301, 165, 20);
		contentPane.add(txtquantity);
		txtquantity.setColumns(10);
		
		txtprice = new JTextField();
		txtprice.setBounds(139, 329, 165, 20);
		contentPane.add(txtprice);
		txtprice.setColumns(10);
		
		txtdiscount = new JTextField();
		txtdiscount.setBounds(139, 360, 165, 20);
		contentPane.add(txtdiscount);
		txtdiscount.setColumns(10);
		
		JLabel lblNewLabel_10 = new JLabel("Discount");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_10.setBounds(24, 361, 114, 14);
		contentPane.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Total");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_11.setBounds(24, 392, 114, 14);
		contentPane.add(lblNewLabel_11);
		
		txttotal = new JTextField();
		txttotal.setEditable(false);
		txttotal.setBounds(139, 391, 165, 20);
		contentPane.add(txttotal);
		txttotal.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("Reset");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				generate_orderid();
			}
		});
		btnNewButton_2.setBounds(139, 104, 89, 23);
		contentPane.add(btnNewButton_2);
		
		Box horizontalBox_1 = Box.createHorizontalBox();
		horizontalBox_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_1.setBounds(10, 11, 320, 144);
		contentPane.add(horizontalBox_1);
		
		JButton btncreateorder = new JButton("Create Order");
		btncreateorder.setBackground(Color.CYAN);
		btncreateorder.setFont(new Font("Tahoma", Font.BOLD, 20));
		btncreateorder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try
		        {
					
					
		       	        orderid = txtorderid.getText();
		       			cusid = txtcusid.getText();
		       			cusname = txtcusname.getText();
		       			cusnic = txtcusnic.getText();
		       			discription = txtdiscription.getText();
		       			quantity = txtquantity.getText();
		       			orderprice = txtprice.getText().trim();
		       			orderdiscount = txtdiscount.getText().trim();
		       			ordertotal = txttotal.getText().trim();
		       			
		       			jtype = comordertype.getSelectedItem().toString();
		    			
		       			//
		       			//excess_km_count();
		       			
		            	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd")  ;
		            	todaydate = dateFormat.format(currentdate.getDate());
		  
		                
		                String message ="";
		                
		            	if(availableempty()) {
		    
		                    
		                    DB db = new DB();
		                    String query = "INSERT INTO neworder (order_id, date, cus_id, cus_name, order_type, order_discription, order_quantity, order_price, order_discount, order_total) VALUES ('"+ orderid+"','"+todaydate+"','"+cusid+"','"+cusname+"','"+jtype+"','"+discription+"','"+quantity +"','"+orderprice+"','"+orderdiscount+"','"+ordertotal+"')";

		                    int rows = db.Save_Del_Update(query);

		                    if (rows>0)
		                    {
		                 
		                    	JOptionPane.showMessageDialog( null, "Data Insertion Sucessful !" );
		                    	
		                    	cleartxt();
		                        
		                    }
		                    else
		                    {
	
		                        JOptionPane.showMessageDialog(null, "Data insertion failed ","Insert Error",JOptionPane.ERROR_MESSAGE);

		                    }
		                }
		                else
		                {
		 
		                    javax.swing.JOptionPane.showMessageDialog(null, 
		                              message, 
		                              "Error", 
		                             javax.swing.JOptionPane.WARNING_MESSAGE);
		           
		
		                }
		        }
		        catch(SQLException ex)
		        {
		                javax.swing.JOptionPane.showMessageDialog(null,
		                    ex.getMessage(),
		                    "SQL Exception",
		                    javax.swing.JOptionPane.WARNING_MESSAGE);
		        }

		   
		        
			
				
			}
		});
		btncreateorder.setBounds(172, 489, 376, 51);
		contentPane.add(btncreateorder);
		
		JButton btnNewButton_4 = new JButton("Advance");
		btnNewButton_4.setBackground(Color.GREEN);
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame payment = new advance();
				payment.setVisible(true);
			}
		});
		btnNewButton_4.setBounds(395, 223, 294, 51);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Customer Receipt");
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_5.setBackground(Color.CYAN);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
			
					
					//report  
					
					try {
						Class.forName("com.mysql.jdbc.Driver");
						Connection con = DriverManager.getConnection("JDBC:MYSQL://localhost:3306/akmeemana","root","");
						
						
						HashMap param = new HashMap();
						param.put("ord_idx",orderequall);
						param.put("day",currentdate);
						param.put("cus_id",cusid);
						param.put("cus_name",cusname);
						
						orderid = txtorderid.getText();
						
						String sql = "select * From neworder";
						
						JasperDesign jdesign = JRXmlLoader.load("C:\\Users\\User\\Desktop\\ICT325\\Project_Akmeemana\\Akmeemana_java\\src\\invoice.jrxml");
						JRDesignQuery updateQuery = new JRDesignQuery();
						
						updateQuery.setText(sql);
						
						jdesign.setQuery(updateQuery);
						
						JasperReport Jreport = JasperCompileManager.compileReport(jdesign);
						JasperPrint JasperPrint = JasperFillManager.fillReport(Jreport, param, con);
						
						JasperViewer.viewReport(JasperPrint, false);
						
						
					}catch(Exception e2) {
						JOptionPane.showMessageDialog(null, e2);
					}
				
				
				
				
				
				
				
			}
		});
		btnNewButton_5.setBounds(395, 360, 294, 59);
		contentPane.add(btnNewButton_5);
		
		JButton btnload = new JButton("Load");
		btnload.setBackground(Color.GREEN);
		btnload.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					ordertotalcal();
					
					
	            	
	            	
					 }
			        catch(Exception e1)
			        {
			                javax.swing.JOptionPane.showMessageDialog(null,
			                    e1.getMessage(),
			                    "SQL Exception",
			                    javax.swing.JOptionPane.WARNING_MESSAGE);
			        }
				}
				
				
				
			
		});
		btnload.setBounds(254, 445, 223, 33);
		contentPane.add(btnload);
		
		textField = new JTextField();
		textField.setBounds(495, 314, 179, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_12 = new JLabel("Order ID");
		lblNewLabel_12.setBounds(415, 322, 46, 14);
		contentPane.add(lblNewLabel_12);
		
		Box horizontalBox_2 = Box.createHorizontalBox();
		horizontalBox_2.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_2.setBounds(10, 169, 320, 262);
		contentPane.add(horizontalBox_2);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox.setBounds(354, 11, 373, 189);
		contentPane.add(horizontalBox);
		
		Box horizontalBox_3 = Box.createHorizontalBox();
		horizontalBox_3.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_3.setBounds(354, 304, 373, 128);
		contentPane.add(horizontalBox_3);
		CustomeraAddCombo();
		
	}
	
	
	//customer imported Details
	private void CustomeraAddCombo()
    {
	try {
	 DB db = new DB();
	 String query = "SELECT cus_telephone FROM customer";
	 ResultSet rs = db.GetData(query);
  
  
	 while(rs.next())
	 {
  
		 comtelephone.addItem(rs.getString(1));
	 }

	}catch(Exception e1) {
  
	javax.swing.JOptionPane.showMessageDialog(null, 
          e1.getMessage(), 
          " Exception", 
          javax.swing.JOptionPane.WARNING_MESSAGE);	}


    }
	
	
	
	// Method to fill Order id text box 
			private void generate_orderid() {
				
				    
				try
	            {
	                DB db = new DB();
	                String query = "SELECT MAX(order_id) AS M_ord_ID FROM neworder";
	                ResultSet rs = db.GetData(query);
	                
	                rs.next();
	                
	                int rows = rs.getRow();
	                if(rows > 0)
	                {
	                    int Max_ord_ID = Integer.parseInt(rs.getString("M_ord_ID"));
	                    Max_ord_ID++;
	                    String ord_ID = String.format("%04d", Max_ord_ID);
	                    txtorderid.setText(String.valueOf(ord_ID));
	                
	                }
	                else
	                {
	                   
	                	 JOptionPane.showMessageDialog(null, "Error","Error occured while creating a new Order Id",JOptionPane.ERROR_MESSAGE);
	                }
	                
	                db.closeCon();
	                    
	            }
	            catch(SQLException ex)
	            {
	                javax.swing.JOptionPane.showMessageDialog(null, 
	                              ex.getMessage(), 
	                              "SQL Exception", 
	                              javax.swing.JOptionPane.WARNING_MESSAGE);
	            }
				    
							
						}
			
			//Calculation for total
			
			private void ordertotalcal() {
				
				try {					
					orderprice = txtprice.getText();
					int orderpricee = Integer.parseInt(orderprice);  
					
					orderdiscount = txtdiscount.getText();
					int orderdiscounts = Integer.parseInt(orderdiscount); 
								
					int Ordertotall = orderpricee  - orderdiscounts ;
					ordertotal = Integer.toString(Ordertotall);
					
					orderid = txtorderid.getText();
					int orderidd = Integer.parseInt(orderid); 
					
					int orderequal = orderidd ;
					orderequall = Integer.toString(orderequal);
					textField.setText(orderequall);
					
				
					txttotal.setText(ordertotal);
								
						}
				catch(Exception e1) {
		            
		            javax.swing.JOptionPane.showMessageDialog(null, 
		                    e1.getMessage(), 
		                    " Exception", 
		                    javax.swing.JOptionPane.WARNING_MESSAGE);	}
			}
			
			//clear textbox
			private void cleartxt() {
				try {
				txtdiscription.setText("");
				txtquantity.setText("");
				txtprice.setText("");
				txtdiscount.setText("");
				txttotal.setText("");     
				}
				catch(Exception e1) {
		             
		             javax.swing.JOptionPane.showMessageDialog(null, 
		                     e1.getMessage(), 
		                     " Exception", 
		                     javax.swing.JOptionPane.WARNING_MESSAGE);	}
		     
				}
			
			// empty text identify
			private boolean availableempty()
		    {
		        boolean notEmpty = true;
		        String message = "";
		        
		     
		        if(txtorderid.getText().trim().isEmpty())
		        {
		            notEmpty = false;
		            message = "Order ID is not generated";
		        }
		        if(txtcusid.getText().trim().isEmpty())
		        {
		            notEmpty = false;
		            message = "Please sselect the customer";
		        }
		        if(txtcusname.getText().trim().isEmpty())
		        {
		            notEmpty = false;
		            message = "Please sselect the customer";
		        }
		        if(txtcusnic.getText().trim().isEmpty())
		        {
		            notEmpty = false;
		            message = "Please sselect the customer";
		        }
		        if(txtdiscription.getText().trim().isEmpty())
		        {
		            notEmpty = false;
		            message = "Discription is empty";
		        }
		        if(txtquantity.getText().trim().isEmpty())
		        {
		            notEmpty = false;
		            message = "Unit quantity is empty";
		        }
		        if(txtprice.getText().trim().isEmpty())
		        {
		            notEmpty = false;
		            message = "Unit Price is Empty";
		        }
		        if(txttotal.getText().trim().isEmpty())
		        {
		            notEmpty = false;
		            message = "Unit Total is empty";
		        }
		       
		        if(!notEmpty)
		        {
		            javax.swing.JOptionPane.showMessageDialog(null, 
		                              message, 
		                              "Empty", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);
		        }
		        
		        return notEmpty;
		    }
}
