import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;

public class report_menu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					report_menu frame = new report_menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public report_menu() {
		setTitle("Reports");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 472, 360);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Reports");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(176, 24, 108, 49);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Customer Report");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//report  
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("JDBC:MYSQL://localhost:3306/akmeemana","root","");
					
					
					
					String sql = "select * From customer";
					
					JasperDesign jdesign = JRXmlLoader.load("C:\\Users\\User\\Desktop\\ICT325\\Project_Akmeemana\\Report\\customer_report.jrxml");
					JRDesignQuery updateQuery = new JRDesignQuery();
					
					updateQuery.setText(sql);
					
					jdesign.setQuery(updateQuery);
					
					JasperReport Jreport = JasperCompileManager.compileReport(jdesign);
					JasperPrint JasperPrint = JasperFillManager.fillReport(Jreport, null, con);
					
					JasperViewer.viewReport(JasperPrint, false);
					
					
				}catch(Exception e2) {
					JOptionPane.showMessageDialog(null, e2);
				}
				
				
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(25, 93, 183, 73);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Advance Report");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				

				//report  
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("JDBC:MYSQL://localhost:3306/akmeemana","root","");
					
					
					
					String sql = "select * From transaction";
					
					JasperDesign jdesign = JRXmlLoader.load("C:\\Users\\User\\Desktop\\ICT325\\Project_Akmeemana\\Report\\advancer.jrxml");
					JRDesignQuery updateQuery = new JRDesignQuery();
					
					updateQuery.setText(sql);
					
					jdesign.setQuery(updateQuery);
					
					JasperReport Jreport = JasperCompileManager.compileReport(jdesign);
					JasperPrint JasperPrint = JasperFillManager.fillReport(Jreport, null, con);
					
					JasperViewer.viewReport(JasperPrint, false);
					
					
				}catch(Exception e2) {
					JOptionPane.showMessageDialog(null, e2);
				}
				
				
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(244, 93, 183, 73);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Order Report");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
//report  
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("JDBC:MYSQL://localhost:3306/akmeemana","root","");
					
					
					
					String sql = "select * From neworder";
					
					JasperDesign jdesign = JRXmlLoader.load("C:\\Users\\User\\Desktop\\ICT325\\Project_Akmeemana\\Akmeemana_java\\src\\order_report.jrxml");
					JRDesignQuery updateQuery = new JRDesignQuery();
					
					updateQuery.setText(sql);
					
					jdesign.setQuery(updateQuery);
					
					JasperReport Jreport = JasperCompileManager.compileReport(jdesign);
					JasperPrint JasperPrint = JasperFillManager.fillReport(Jreport, null, con);
					
					JasperViewer.viewReport(JasperPrint, false);
					
					
				}catch(Exception e2) {
					JOptionPane.showMessageDialog(null, e2);
				}
				
				
				
				
				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(134, 187, 183, 62);
		contentPane.add(btnNewButton_2);
	}
}
