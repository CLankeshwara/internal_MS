import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.Box;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Font;

public class new_customer extends JFrame {

	private JPanel contentPane;
	private JTextField txtcustomerid;
	private JTextField txtcustomername;
	private JTextField txttelephone;
	private JTextField txtaddress;
	private JTextField txtnic;
	private Boolean check;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new_customer frame = new new_customer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public new_customer() {
		setTitle("New Customer");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 485, 411);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Customer ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(48, 54, 126, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Customer Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(48, 85, 150, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Custommer Telephone");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(48, 120, 171, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Customer address");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(48, 150, 126, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Customer NIC");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(48, 180, 156, 14);
		contentPane.add(lblNewLabel_4);
		
		txtcustomerid = new JTextField();
		txtcustomerid.setEditable(false);
		txtcustomerid.setBounds(231, 53, 177, 20);
		contentPane.add(txtcustomerid);
		txtcustomerid.setColumns(10);
		CUSID();
		
		
		txtcustomername = new JTextField();
		txtcustomername.setBounds(231, 84, 177, 20);
		contentPane.add(txtcustomername);
		txtcustomername.setColumns(10);
		
		txttelephone = new JTextField();
		txttelephone.setBounds(231, 119, 177, 20);
		contentPane.add(txttelephone);
		txttelephone.setColumns(10);
		
		txtaddress = new JTextField();
		txtaddress.setBounds(231, 149, 177, 20);
		contentPane.add(txtaddress);
		txtaddress.setColumns(10);
		
		txtnic = new JTextField();
		txtnic.setBounds(231, 179, 177, 20);
		contentPane.add(txtnic);
		txtnic.setColumns(10);
		
		JButton btnsubmit = new JButton("Save");
		btnsubmit.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnsubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//insert data to customer
				
				try
		        {
		            
		             check = true;		
		            
		            	String cus_id = txtcustomerid.getText().trim();
		                String cus_name = txtcustomername.getText().trim();
		                String cus_telephone = txttelephone.getText().trim();
		                String cus_nic = txtnic.getText().trim();
		                String cus_address = txtaddress.getText();
		       
		                
		                
		                
		                String message ="";
		                TextValidations();
		                
		                if(cus_id.isEmpty())
		                {
		                    check = false;
		                    message = "Customer ID is Empty";
		                }
		                if(cus_name.isEmpty())
		                {
		                    check = false;
		                    message = "Customer Name is Empty";
		                }
		                if(cus_telephone.isEmpty())
		                {
		                    check = false;
		                    message = "Customer Driving Licen Number is Empty";
		                }
		                if(cus_nic.isEmpty())
		                {
		                    check = false;
		                    message = "Customer NIC number is Empty";
		                }
		                if(cus_address.isEmpty())
		                {
		                    check = false;
		                    message = "Customer Address is Empty";
		                }
		                

		                if(check)
		                	
		                	
		                {
		                    
		                    DB db = new DB();
		                    String query = "INSERT INTO customer (cus_id,cus_name,cus_telephone,cus_nic,cus_address) VALUES ('"+cus_id+"','"+cus_name+"','"+cus_telephone+"','"+cus_nic+"','"+cus_address+"')";

		                    int rows = db.Save_Del_Update(query);

		                    if (rows>0)
		                    {
		                 
		                    	JOptionPane.showMessageDialog( null, "Data Insertion Sucessfully !" );
		                        CUSID();
		                    	
		                        
		                        
		                        
		                        
		                        
		                        //clear fields
		                        txtcustomername.setText("");
		        				txttelephone.setText("");
		        				txtaddress.setText("");
		        				txtnic.setText("");
		                        
		                    }
		                    else
		                    {
	
		                        JOptionPane.showMessageDialog(null, "Data insertion failed ","Insert Error",JOptionPane.ERROR_MESSAGE);

		                    }
		                }
		                else
		                {
		 
		                    javax.swing.JOptionPane.showMessageDialog(null, 
		                              message, 
		                              "Error", 
		                             javax.swing.JOptionPane.WARNING_MESSAGE);
		           
		
		                }
		        }
		        catch(SQLException ex)
		        {
		                javax.swing.JOptionPane.showMessageDialog(null,
		                    ex.getMessage(),
		                    "SQL Exception",
		                    javax.swing.JOptionPane.WARNING_MESSAGE);
		        }
				
				
			}
		});
		btnsubmit.setBounds(156, 278, 150, 51);
		contentPane.add(btnsubmit);
		
		JButton btnclear = new JButton("Clear");
		btnclear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtcustomername.setText("");
				txttelephone.setText("");
				txtaddress.setText("");
				txtnic.setText("");
			}
		});
		btnclear.setBounds(319, 204, 89, 23);
		contentPane.add(btnclear);
		
		/*JButton btnNewButton = new JButton("Customer Report");
		btnNewButton.addActionListener(new ActionListener() {
			private JasperPrint jprint;
			public void actionPerformed(ActionEvent e) {
				
				//report  
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("JDBC:MYSQL://localhost:3306/akmeemana","root","");
					
					
					
					String sql = "select * From customer";
					
					JasperDesign jdesign = JRXmlLoader.load("C:\\Users\\User\\Desktop\\ICT325\\Project_Akmeemana\\Report\\customer_report.jrxml");
					JRDesignQuery updateQuery = new JRDesignQuery();
					
					updateQuery.setText(sql);
					
					jdesign.setQuery(updateQuery);
					
					JasperReport Jreport = JasperCompileManager.compileReport(jdesign);
					JasperPrint JasperPrint = JasperFillManager.fillReport(Jreport, null, con);
					
					JasperViewer.viewReport(JasperPrint, false);
					
					
				}catch(Exception e2) {
					JOptionPane.showMessageDialog(null, e2);
				}
				
				
				
			}
		});
		btnNewButton.setBounds(307, 343, 115, 39);
		contentPane.add(btnNewButton);*/
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox.setBounds(25, 24, 424, 229);
		contentPane.add(horizontalBox);
	}
	
	private void CUSID()
    {
        try
            {
                DB db = new DB();
                String query = "SELECT MAX(cus_id) AS McusID FROM customer";
                ResultSet rs = db.GetData(query);
                
                rs.next();
                
                int rows = rs.getRow();
                if(rows > 0)
                {
                    int McusID = Integer.parseInt(rs.getString("McusID"));
                    McusID++;
                    String cusID = String.format("%04d", McusID);
                    txtcustomerid.setText(String.valueOf(cusID));
                
                }
                else
                {
                   // output_lbl.setText("Minimum ID not set in the table in the database");
                	 JOptionPane.showMessageDialog(null, "Data insertion failed","Insert Error",JOptionPane.ERROR_MESSAGE);
                }
                
                db.closeCon();
                    
            }
            catch(SQLException ex)
            {
                javax.swing.JOptionPane.showMessageDialog(null, 
                              ex.getMessage(), 
                              "SQL Exception", 
                              javax.swing.JOptionPane.WARNING_MESSAGE);
            }
    }
	
	
	private void TextValidations()
    {	
		// contact one text length check
		String txtcon1ST=txttelephone.getText();
		ContactLengthTest(txtcon1ST,"Contact Mobile length is not valid");
		
		// contact one character check
		CharachterTest(txtcon1ST,"Contact Mobile can only contain numbers");
	
		// nic number text length check 
		String txtnicST;
		txtnicST=txtnic.getText();
		if (txtnicST.length()==10 || txtnicST.length()==12) {
			
		}
		else {
			check = false;
			JOptionPane.showMessageDialog(null, "NIC number is not valid:", "Validation Error",JOptionPane.WARNING_MESSAGE);
		}
		
    }
	
	private void ContactLengthTest(String ContactLengthTestInput, String MessageZ)
    {

	if (ContactLengthTestInput.length()!=10) {
		check = false;
		JOptionPane.showMessageDialog(null, MessageZ , "Validation Error",JOptionPane.WARNING_MESSAGE);
	} 
    }
	
	
	
	
	
private void CharachterTest(String CharTestInput,String MessageX) {
		
		char[] txtConArrX = CharTestInput.toCharArray();
		char[] numX = {'0','1','2','3','4','5','6','7','8','9'};
		int j;

		
		for (int i = 0; i < txtConArrX.length; i++) {
		
			  for( j = 0; j < numX.length; j++) {
				  System.out.println("txtConArrX[i]: "+String.valueOf(txtConArrX[i]));
				  System.out.println("numX[j]: "+String.valueOf(numX[j]));
			    if (txtConArrX[i]==numX[j]) {
			
			    	break;
			    }
			    
			  }
			  if ((numX.length)==j) {
				 // System.out.println(numX[i]);
				  JOptionPane.showMessageDialog(null, MessageX, "Validation Error",JOptionPane.WARNING_MESSAGE);
				  check = false;
				  break;
			  }
			  
			 
			}		

	}
	
}
