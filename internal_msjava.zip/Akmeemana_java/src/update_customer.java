import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.Box;
import javax.swing.border.BevelBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;

public class update_customer extends JFrame {

	private JPanel contentPane;
	private JTextField txtcustomerid;
	private JTextField txtcustomername;
	private JTextField txtcustomertelephone;
	private JTextField txtcustomeraddress;
	private JTextField txtcustomernic;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					update_customer frame = new update_customer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public update_customer() {
		setTitle("Mistake Customer");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 523, 425);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Customer ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(45, 119, 126, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Customer Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(45, 150, 150, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Custommer Telephone");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(45, 185, 171, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Customer address");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(45, 215, 126, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Customer NIC");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(45, 245, 156, 14);
		contentPane.add(lblNewLabel_4);
		
		txtcustomerid = new JTextField();
		txtcustomerid.setBounds(224, 118, 171, 20);
		contentPane.add(txtcustomerid);
		txtcustomerid.setColumns(10);
		
		txtcustomername = new JTextField();
		txtcustomername.setBounds(224, 149, 171, 20);
		contentPane.add(txtcustomername);
		txtcustomername.setColumns(10);
		
		txtcustomertelephone = new JTextField();
		txtcustomertelephone.setBounds(224, 184, 171, 20);
		contentPane.add(txtcustomertelephone);
		txtcustomertelephone.setColumns(10);
		
		txtcustomeraddress = new JTextField();
		txtcustomeraddress.setBounds(224, 214, 171, 20);
		contentPane.add(txtcustomeraddress);
		txtcustomeraddress.setColumns(10);
		
		txtcustomernic = new JTextField();
		txtcustomernic.setBounds(224, 244, 171, 20);
		contentPane.add(txtcustomernic);
		txtcustomernic.setColumns(10);
		
		JButton btnsave = new JButton("Save");
		btnsave.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnsave.setBounds(146, 302, 150, 53);
		contentPane.add(btnsave);
		
		JComboBox comtelephone = new JComboBox();
		comtelephone.setBounds(224, 39, 171, 22);
		contentPane.add(comtelephone);
		
		JLabel lblNewLabel_5 = new JLabel("Customer Telephone Number");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(36, 41, 180, 14);
		contentPane.add(lblNewLabel_5);
		
		JButton btnNewButton_1 = new JButton("Search");
		btnNewButton_1.setBounds(224, 72, 89, 23);
		contentPane.add(btnNewButton_1);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox.setBounds(36, 106, 376, 180);
		contentPane.add(horizontalBox);
		
		Box horizontalBox_1 = Box.createHorizontalBox();
		horizontalBox_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_1.setBounds(22, 30, 401, 73);
		contentPane.add(horizontalBox_1);
	}
}
