import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import com.toedter.calendar.JDateChooser;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.Box;
import javax.swing.border.BevelBorder;

public class advance extends JFrame {

	private JPanel contentPane;
	private JTextField txtdiscription;
	private JTextField txtadvanceamount;
	private JComboBox comorderid;
	private JTextField txtadvanceid;
	
	
	private JDateChooser currentday;
	
	private Date xdate = new Date();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					advance frame = new advance();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public advance() {
		setTitle("Advance");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 541, 530);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Advance ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(71, 77, 103, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Order ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(71, 123, 132, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Advance Date");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(71, 174, 140, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Discription");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(71, 224, 86, 14);
		contentPane.add(lblNewLabel_3);
		
		txtadvanceid = new JTextField();
		txtadvanceid.setEditable(false);
		txtadvanceid.setBounds(213, 74, 245, 20);
		contentPane.add(txtadvanceid);
		txtadvanceid.setColumns(10);
		adid();
		
		txtdiscription = new JTextField();
		txtdiscription.setHorizontalAlignment(SwingConstants.LEFT);
		txtdiscription.setBounds(213, 221, 245, 110);
		contentPane.add(txtdiscription);
		txtdiscription.setColumns(10);
		
		txtadvanceamount = new JTextField();
		txtadvanceamount.setBounds(213, 342, 146, 20);
		contentPane.add(txtadvanceamount);
		txtadvanceamount.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Advance Amount");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(71, 345, 140, 14);
		contentPane.add(lblNewLabel_4);
		
		comorderid = new JComboBox();
		comorderid.setBounds(213, 121, 245, 22);
		contentPane.add(comorderid);
		
		currentday = new JDateChooser();
		currentday.setBounds(213, 168, 146, 20);
		contentPane.add(currentday);
		currentday.setDateFormatString("yyyy/MM/dd");
		currentday.setDate(xdate);
		
		JButton btnsave = new JButton("Save");
		btnsave.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnsave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try
		        {
		            
		            boolean check = true;		
		            
		            	String ad_id = txtadvanceid.getText().trim();
		                String ad_discription = txtdiscription.getText().trim();
		                String ad_amount = txtadvanceamount.getText().trim();
		                
		                String ordercombo = comorderid.getSelectedItem().toString();
		       
		                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd")  ;
		            	String todaydate = dateFormat.format(currentday.getDate());
		                
		                
		                String message ="";
		                
		                if(ad_id.isEmpty())
		                {
		                    check = false;
		                    message = "advance ID is not generated";
		                }
		                if(ad_discription.isEmpty())
		                {
		                    check = false;
		                    message = "advance discription is Empty";
		                }
		                if(ad_amount.isEmpty())
		                {
		                    check = false;
		                    message = "Advance amount is Empty";
		                }
		                if(check)
		                	
		                	
		                {
		                    
		                    DB db = new DB();
		                    String query = "INSERT INTO transaction (tno,advance_date,order_id,discription,advance_amount) VALUES ('"+ad_id+"','"+todaydate+"','"+ordercombo+"','"+ad_discription+"','"+ad_amount+"')";

		                    int rows = db.Save_Del_Update(query);

		                    if (rows>0)
		                    {
		                 
		                    	JOptionPane.showMessageDialog( null, "Data Insertion Sucessfully !" );
		                    	adid();
		                    	
		                        
		                        
		                        
		                        
		                        
		                        //clear fields
		                        txtdiscription.setText("");
		        				txtadvanceamount.setText("");
		        				
		                    }
		                    else
		                    {
	
		                        JOptionPane.showMessageDialog(null, "Data insertion failed ","Insert Error",JOptionPane.ERROR_MESSAGE);

		                    }
		                }
		                else
		                {
		 
		                    javax.swing.JOptionPane.showMessageDialog(null, 
		                              message, 
		                              "Error", 
		                             javax.swing.JOptionPane.WARNING_MESSAGE);
		           
		
		                }
		        }
		        catch(SQLException ex)
		        {
		                javax.swing.JOptionPane.showMessageDialog(null,
		                    ex.getMessage(),
		                    "SQL Exception",
		                    javax.swing.JOptionPane.WARNING_MESSAGE);
		        }
				
				
				
			}
		});
		btnsave.setBounds(184, 399, 172, 60);
		contentPane.add(btnsave);
		
		JLabel lblNewLabel_5 = new JLabel("Advance Payment");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel_5.setBounds(144, 11, 253, 51);
		contentPane.add(lblNewLabel_5);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox.setBounds(32, 58, 462, 314);
		contentPane.add(horizontalBox);
		
		
		
		orderselect();
	}
	//order id
	private void orderselect()
    {
	try {
	 DB db = new DB();
	 String query = "SELECT order_id FROM neworder";
	 ResultSet rs = db.GetData(query);
  
  
	 while(rs.next())
	 {
  
		 comorderid.addItem(rs.getString(1));
	 }

	}catch(Exception e1) {
  
	javax.swing.JOptionPane.showMessageDialog(null, 
          e1.getMessage(), 
          " Exception", 
          javax.swing.JOptionPane.WARNING_MESSAGE);	}


    }
	
	//advance id
	private void adid()
    {
        try
            {
                DB db = new DB();
                String query = "SELECT MAX(tno) AS McusID FROM transaction";
                ResultSet rs = db.GetData(query);
                
                rs.next();
                
                int rows = rs.getRow();
                if(rows > 0)
                {
                    int McusID = Integer.parseInt(rs.getString("McusID"));
                    McusID++;
                    String cusID = String.format("%04d", McusID);
                    txtadvanceid.setText(String.valueOf(cusID));
                
                }
                else
                {
                   // output_lbl.setText("Minimum ID not set in the table in the database");
                	 JOptionPane.showMessageDialog(null, "Data insertion failed","Insert Error",JOptionPane.ERROR_MESSAGE);
                }
                
                db.closeCon();
                    
            }
            catch(SQLException ex)
            {
                javax.swing.JOptionPane.showMessageDialog(null, 
                              ex.getMessage(), 
                              "SQL Exception", 
                              javax.swing.JOptionPane.WARNING_MESSAGE);
            }
    }
}
