	import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.SystemColor;
//import java.awt.Window;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;
import java.awt.Color;




public class login {

	private JFrame frmLogin;
	private JTextField txtusername;
	private JTextField txtpassword;
	public static String userIDD = "";
	private JPasswordField passwordtxt;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login window = new login();
					window.frmLogin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLogin = new JFrame();
		frmLogin.setTitle("Login");
		frmLogin.setBounds(100, 100, 381, 450);
		frmLogin.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmLogin.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOGIN");
		lblNewLabel.setBackground(SystemColor.window);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 29));
		lblNewLabel.setBounds(130, 33, 142, 39);
		frmLogin.getContentPane().add(lblNewLabel);
		
		JLabel lblusername = new JLabel("Username");
		lblusername.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblusername.setBounds(43, 113, 95, 14);
		frmLogin.getContentPane().add(lblusername);
		
		JLabel lblpassword = new JLabel("Password");
		lblpassword.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblpassword.setBounds(43, 154, 77, 14);
		frmLogin.getContentPane().add(lblpassword);
		
		txtusername = new JTextField();
		txtusername.setBounds(148, 111, 170, 20);
		frmLogin.getContentPane().add(txtusername);
		txtusername.setColumns(10);
		
		//txtpassword = new JTextField();
		//txtpassword.setBounds(165, 152, 170, 20);
		//frmLogin.getContentPane().add(txtpassword);
		//txtpassword.setColumns(10);
		
		JButton btnlogin = new JButton("Login");
		btnlogin.setBackground(Color.CYAN);
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				//login button code
				try {
				
				String username = txtusername.getText();
				String password = passwordtxt.getText();
				
				if (username.trim().isEmpty() || password.trim().isEmpty())
	            {
	            
					JOptionPane.showMessageDialog(null, "Please fill all fields","Login Error",JOptionPane.ERROR_MESSAGE);
	                
	            }
	            else
	            {
	                
	                
	                DB db = new DB();
	                String query = "SELECT user_name,user_type FROM User WHERE user_name='"+username+"' AND password='"+password+"'";
	                ResultSet rs = db.GetData(query);
	                
	                
	                rs.next();
	                int rows = rs.getRow();
	                
	                
	                if (rows>0)
	                {
	                	userIDD = rs.getString("user_name");
	                	
	
	                    String uType = rs.getString("user_type");
	                    
	                    
	                    if (uType.equalsIgnoreCase("1") || uType.equalsIgnoreCase("Admin"))
	                    {
	                    	
	                    	JFrame home = new home();
							home.setVisible(true);
							frmLogin.setVisible(false);
	                        
	                    }
	                    else if(uType.equalsIgnoreCase("User"))
	                    {
	             
	                    	JFrame homeu = new homeuser();
							homeu.setVisible(true);
							frmLogin.setVisible(false);
						
	                    }
	                    db.closeCon();
	                    
	                }
	                else
	                {
	        
	                	JOptionPane.showMessageDialog(null, "Invalid Username or Password","Try again",JOptionPane.ERROR_MESSAGE);
		                
	                }
	            }}
				
				catch(SQLException e1)
		        {
		            javax.swing.JOptionPane.showMessageDialog(null, 
		                              e1.getMessage(), 
		                              "SQL Exception", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);	}
				
			}
		});
		
		btnlogin.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnlogin.setBounds(116, 214, 119, 44);
		frmLogin.getContentPane().add(btnlogin);
		
		JButton btnclear = new JButton("Clear");
		btnclear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//clear texts
				txtusername.setText(null);
				passwordtxt.setText(null);
			}
		});
		btnclear.setBounds(229, 291, 89, 23);
		frmLogin.getContentPane().add(btnclear);
		
		JButton btnexit = new JButton("Exit");
		btnexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnexit.setBounds(43, 291, 89, 23);
		frmLogin.getContentPane().add(btnexit);
		
		passwordtxt = new JPasswordField();
		passwordtxt.setBounds(148, 152, 170, 20);
		frmLogin.getContentPane().add(passwordtxt);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Show Password");
		chckbxNewCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(chckbxNewCheckBox.isSelected()) {
					passwordtxt.setEchoChar((char)0);
				}else {
					passwordtxt.setEchoChar('*');
				}
				
			}
		});
		chckbxNewCheckBox.setBounds(214, 176, 135, 23);
		frmLogin.getContentPane().add(chckbxNewCheckBox);
	}
	}
