import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.Box;
import javax.swing.border.BevelBorder;

public class update_user extends JFrame {

	private JPanel contentPane;
	private JPasswordField passnewrepassword;
	private JPasswordField passnewpassword;
	private JPasswordField passcurrent;
	private JTextField txtusername;
	
	private String username = "";
	private JComboBox comusername;

	


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					update_user frame = new update_user();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public update_user() {
		setTitle("Change Password");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 531, 509);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		/*JLabel lblNewLabel = new JLabel("User Name");
		lblNewLabel.setEnabled(false);
		lblNewLabel.setBounds(33, 25, 77, 14);
		contentPane.add(lblNewLabel);*/
		
		JLabel lblNewLabel_1 = new JLabel("Previouse Password");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(56, 191, 151, 20);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("New Password");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(56, 222, 128, 20);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Re-enter New Password");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(56, 253, 191, 20);
		contentPane.add(lblNewLabel_3);
		
		passnewrepassword = new JPasswordField();
		passnewrepassword.setBounds(244, 255, 201, 20);
		contentPane.add(passnewrepassword);
		
		passnewpassword = new JPasswordField();
		passnewpassword.setBounds(244, 224, 201, 20);
		contentPane.add(passnewpassword);
		
		passcurrent = new JPasswordField();
		passcurrent.setBounds(244, 193, 201, 20);
		contentPane.add(passcurrent);
		
		comusername = new JComboBox();
		comusername.setBounds(244, 44, 201, 28);
		contentPane.add(comusername);
		
		JButton btnsearch = new JButton("Search");
		btnsearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					String username = comusername.getSelectedItem().toString();
				   // String  = txtsearch.getText();
				
					if (username.trim().isEmpty() )
		            {
		            
						JOptionPane.showMessageDialog(null, "Please fill all fields","Login Error",JOptionPane.ERROR_MESSAGE);
		                
		            }
		            else
		            {
		                
		                
		                DB db = new DB();
		                String query = "SELECT * FROM user WHERE user_name='"+username+"'";
		                ResultSet rs = db.GetData(query);
		                
		                
		                rs.next();
		                int rows = rs.getRow();
		                
		                
		                if (rows>0)
		                {
		                	username = rs.getString("user_name");
		                	
		                	
		                
		                	
		                	txtusername.setText(username);
		                	
		                	
		                	
		                
		                    
		                }
		                else
		                {
		        
		                	JOptionPane.showMessageDialog(null, "Invalid Username","Try again",JOptionPane.ERROR_MESSAGE);
			                
		                }	
		            }}
				
				catch(SQLException e1)
		        {
		            javax.swing.JOptionPane.showMessageDialog(null, 
		                              e1.getMessage(), 
		                              "SQL Exception", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);	}
			
			}
				
				
				
		});
		btnsearch.setBounds(244, 83, 83, 24);
		contentPane.add(btnsearch);
		
		JButton btnsave = new JButton("Save");
		btnsave.setFont(new Font("Tahoma", Font.BOLD, 19));
		btnsave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(checkNotEmpty())
		        {
		            try
		            {
		                //String uID = Login.getUserID();
		                String uName = txtusername.getText();
		                String currPass = passcurrent.getText();
		                String newPass1 = passnewpassword.getText();
		                String newPass2 = passnewrepassword.getText();
		                
		                DB db = new DB();
		                String query = "SELECT username FROM User WHERE user_name = '"+uName+"' AND password = '"+currPass+"' ";
		                java.sql.ResultSet rs = db.GetData(query);
		                
		                rs.next();
		                int row = rs.getRow();
		                
		                if(row>0 && username.equals(rs.getString("username")))
		                {
		                    if(newPass1.equals(newPass2))
		                    {
		                        String newPass = newPass1;
		                        
		                        db = new DB();
		                        query = "UPDATE User SET password = '"+newPass+"' WHERE user_name = '"+username+"' ";
		                        int rows = db.Save_Del_Update(query);
		                        
		                        if (rows>0)
		                        {
		           
		                        	JOptionPane.showMessageDialog( null, "Password Reset Sucessful !" );
		                            
		                        }
		                        else
		                        {
		                      
		                        	 JOptionPane.showMessageDialog(null, "Password Reset Unsuccesful ","Try Again",JOptionPane.ERROR_MESSAGE);
		                            
		                        }
		                    }
		                    else
		                    {
		               
		                    	 JOptionPane.showMessageDialog(null, "Password doesnt match","Retype password",JOptionPane.ERROR_MESSAGE);
		                        
		                    }
		                }
		                else
		                {
		
		                    javax.swing.JOptionPane.showMessageDialog(null, 
		                              "Invalid current password", 
		                              "Error", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);
		                    
		                }
		                passcurrent.setText("");
		    	        passnewpassword.setText("");
		    	        passnewrepassword.setText("");
		    	    
		            
		                
		            }
		            catch (java.sql.SQLException e1)
		            {
		                javax.swing.JOptionPane.showMessageDialog(null, 
		                              e1.getMessage(), 
		                              "SQL Exception", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);
		            }
		            
		            
		        }
				
				
				
			}
		});
		btnsave.setBounds(182, 332, 157, 71);
		contentPane.add(btnsave);
		
		txtusername = new JTextField();
		txtusername.setEditable(false);
		txtusername.setBounds(244, 162, 201, 20);
		contentPane.add(txtusername);
		txtusername.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(56, 160, 117, 20);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_4 = new JLabel("Check Your Username");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(54, 44, 193, 30);
		contentPane.add(lblNewLabel_4);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox.setBounds(21, 28, 464, 99);
		contentPane.add(horizontalBox);
		
		JButton btnclear = new JButton("Clear");
		btnclear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtusername.setText("");
				passcurrent.setText("");
    	        passnewpassword.setText("");
    	        passnewrepassword.setText("");
			}
		});
		btnclear.setBounds(354, 286, 89, 23);
		contentPane.add(btnclear);
		
		Box horizontalBox_1 = Box.createHorizontalBox();
		horizontalBox_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_1.setBounds(41, 138, 429, 186);
		contentPane.add(horizontalBox_1);
		comusernameadd();
	}
	
	
	private boolean checkNotEmpty()
    {
        boolean notEmpty = true;
        String reason ="";
        if(username.trim().isEmpty())
        {
            notEmpty = false;
            reason ="User ID not set";
        }
        if(passcurrent.getText().trim().isEmpty())
        {
            notEmpty = false;
            reason ="Current Password is Empty";
        }
        if(passnewpassword.getText().trim().isEmpty())
        {
            notEmpty = false;
            reason ="New Password is Empty";
        }
        if(passnewrepassword.getText().trim().isEmpty())
        {
            notEmpty = false;
            reason ="Re-tyoe new Password";
        }
        if(!notEmpty)
        {
            javax.swing.JOptionPane.showMessageDialog(null, 
                              reason, 
                              "Empty", 
                              javax.swing.JOptionPane.WARNING_MESSAGE);
        }
        return notEmpty;
        
    }
	
	private void comusernameadd()
    {
	try {
	 DB db = new DB();
	 String query = "SELECT user_name FROM user";
	 ResultSet rs = db.GetData(query);
  
  
	 while(rs.next())
	 {
  
		 comusername.addItem(rs.getString(1));
	 }

	}catch(Exception e1) {
  
	javax.swing.JOptionPane.showMessageDialog(null, 
          e1.getMessage(), 
          " Exception", 
          javax.swing.JOptionPane.WARNING_MESSAGE);	}


    }
}
