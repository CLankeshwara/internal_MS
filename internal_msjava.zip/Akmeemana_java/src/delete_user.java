import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.Box;
import javax.swing.border.BevelBorder;
import java.awt.Color;


public class delete_user extends JFrame {

	private JPanel contentPane;
	private JTextField txtusername;
	private JPasswordField passwordtxt;
	
	
	private JComboBox comusername;
	public static String userIDD = "";
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					delete_user frame = new delete_user();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public delete_user() {
		setTitle("Deleete User");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 572, 446);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		comusername = new JComboBox();
		comusername.setBounds(260, 68, 203, 22);
		contentPane.add(comusername);
		
		JLabel lblNewLabel = new JLabel("Select Username");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(71, 70, 175, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(116, 170, 123, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(116, 207, 116, 14);
		contentPane.add(lblNewLabel_2);
		
		txtusername = new JTextField();
		txtusername.setEditable(false);
		txtusername.setBounds(262, 169, 175, 20);
		contentPane.add(txtusername);
		txtusername.setColumns(10);
		
		passwordtxt = new JPasswordField();
		passwordtxt.setBounds(262, 206, 175, 20);
		contentPane.add(passwordtxt);
		
		JButton btndelete = new JButton("Delete");
		btndelete.setFont(new Font("Tahoma", Font.BOLD, 20));
		btndelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				try {
					
					String username = txtusername.getText();
					String password = passwordtxt.getText();
					
					if (username.trim().isEmpty() || password.trim().isEmpty())
		            {
		            
						JOptionPane.showMessageDialog(null, "Please fill all fields","Login Error",JOptionPane.ERROR_MESSAGE);
		                
		            }
		            else
		            {
		                
		                
		                DB db = new DB();
		                String query = "DELETE user_name FROM User WHERE user_name='"+username+"'";
		                ResultSet rs = db.GetData(query);
		                
		                
		                rs.next();
		                int rows = db.Save_Del_Update(query);
		                
		                
		                if (rows>0)
		                {
		                	userIDD = rs.getString("user_name");
		                	
		
		                    String uType = rs.getString("user_type");
		                    
		                    
		                    if (uType.equalsIgnoreCase("1") || uType.equalsIgnoreCase("Admin"))
		                    {
		                    	
		                    	JFrame home = new home();
								home.setVisible(true);
								
		                        
		                    }
		                    else if(uType.equalsIgnoreCase("User"))
		                    {
		             
		                    	JFrame homeu = new homeuser();
								homeu.setVisible(true);
								
							
		                    }
		                    db.closeCon();
		                    
		                }
		                else
		                {
		        
		                	JOptionPane.showMessageDialog(null, "Invalid Username or Password","Try again",JOptionPane.ERROR_MESSAGE);
			                
		                }
}}
				
				catch(SQLException e1)
		        {
		            javax.swing.JOptionPane.showMessageDialog(null, 
		                              e1.getMessage(), 
		                              "SQL Exception", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);	}
				
				
				
				
				
				
				
				
				
			}
		});
		btndelete.setBounds(179, 302, 175, 66);
		contentPane.add(btndelete);
		
		JButton btnclear = new JButton("Clear");
		btnclear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtusername.setText("");
				passwordtxt.setText("");
				
			}
		});
		btnclear.setBounds(372, 237, 65, 23);
		contentPane.add(btnclear);
		
		JButton btnsearch = new JButton("Search");
		btnsearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					String username = comusername.getSelectedItem().toString();
				   // String  = txtsearch.getText();
				
					if (username.trim().isEmpty() )
		            {
		            
						JOptionPane.showMessageDialog(null, "Please fill all fields","Login Error",JOptionPane.ERROR_MESSAGE);
		                
		            }
		            else
		            {
		                
		                
		                DB db = new DB();
		                String query = "SELECT * FROM user WHERE user_name='"+username+"'";
		                ResultSet rs = db.GetData(query);
		                
		                
		                rs.next();
		                int rows = rs.getRow();
		                
		                
		                if (rows>0)
		                {
		                	username = rs.getString("user_name");
		                	
		                	
		                
		                	
		                	txtusername.setText(username);
		                	
		                	
		                	
		                
		                    
		                }
		                else
		                {
		        
		                	JOptionPane.showMessageDialog(null, "Invalid Username","Try again",JOptionPane.ERROR_MESSAGE);
			                
		                }	
		            }}
				
				catch(SQLException e1)
		        {
		            javax.swing.JOptionPane.showMessageDialog(null, 
		                              e1.getMessage(), 
		                              "SQL Exception", 
		                              javax.swing.JOptionPane.WARNING_MESSAGE);	}
				
				
			}
		});
		btnsearch.setBounds(260, 98, 95, 23);
		contentPane.add(btnsearch);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox.setBounds(25, 45, 494, 97);
		contentPane.add(horizontalBox);
		
		Box horizontalBox_1 = Box.createHorizontalBox();
		horizontalBox_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_1.setBounds(51, 153, 431, 130);
		contentPane.add(horizontalBox_1);
		
		JLabel lblNewLabel_3 = new JLabel("WARNING! When you delete the details it shoud be erase all of data records.");
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_3.setBounds(52, 11, 444, 22);
		contentPane.add(lblNewLabel_3);
		comusernameadd();
	}
	
	
	private void comusernameadd()
    {
	try {
	 DB db = new DB();
	 String query = "SELECT user_name FROM user";
	 ResultSet rs = db.GetData(query);
  
  
	 while(rs.next())
	 {
  
		 comusername.addItem(rs.getString(1));
	 }

	}catch(Exception e1) {
  
	javax.swing.JOptionPane.showMessageDialog(null, 
          e1.getMessage(), 
          " Exception", 
          javax.swing.JOptionPane.WARNING_MESSAGE);	}


    }
}
